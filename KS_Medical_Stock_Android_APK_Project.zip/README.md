# KS Medical Stock Android APK

This project wraps the existing Netlify PWA in an Android WebView.

Online app URL:
https://ks-medical-stock-app.netlify.app/

## Free build using GitHub Actions

1. Create a new GitHub repository.
2. Upload all files/folders from this project.
3. Open the repository's **Actions** tab.
4. Select **Build KS Medical APK**.
5. Tap **Run workflow**.
6. When it finishes, open the workflow run and download the artifact named **KS-Medical-Stock-APK**.
7. Extract it and install `app-debug.apk` on your Android phone.

This is a debug APK intended for personal use/sideloading, not Play Store publication.

## Data note

The WebView enables JavaScript and DOM storage so browser-based localStorage data can persist inside the APK. Keep using the same installed APK/app data and avoid clearing its storage. Your actual app remains hosted on Netlify, so website changes can be delivered without rebuilding this wrapper.
